<?php
/**
 * Template Name: Blog Page
 *
 * @author Designova (designova.net)
 * @theme Amaze
 */

?>
