<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar('amaze_side') ) : ?><?php endif; ?>