jQuery(document).ready(function($){
    $('#amaze_pagebg_color').wpColorPicker();
});