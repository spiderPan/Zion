skrollr.init({
		forceHeight: false
	});
// // skrollr.menu.init(s);
// var s = skrollr.init({
// 			forceHeight: false
// 		});

// skrollr.menu.init(s, {
//     animate: true, //skrollr will smoothly animate to the new position using `animateTo`.
//     duration: 900, //How long the animation should take in ms.
//     easing: 'sqrt' //The easing function to use.
// });