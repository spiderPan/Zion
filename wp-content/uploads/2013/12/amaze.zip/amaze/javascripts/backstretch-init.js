jQuery(document).ready(function($) {
	
       $.backstretch(slides, { fade: 3000,duration: 4000});
});