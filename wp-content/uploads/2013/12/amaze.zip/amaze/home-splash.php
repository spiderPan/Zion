<?php
/**
 * Template Name: Home Splash Screen
 *
 * @author Designova (designova.net)
 * @theme Reason
 */
?>
